package com.pilador.model;

import java.util.Arrays;

public class Lexico implements Constants {
    private int position;
    private String input;

    private String[] lines;

    public Lexico() {
        this("");
    }

    public Lexico(String input) {
        setInput(input);
        setLines(input);
    }

    public void setInput(String input) {
        this.input = input;
        setPosition(0);
    }

    public void setPosition(int pos) {
        position = pos;
    }

    public void setLines(String input) {
        lines = input.split("\n");
    }

    public Token nextToken() throws LexicalError {
        if (!hasInput())
            return null;

        int start = position;

        int state = 0;
        int lastState = 0;
        int endState = -1;
        int end = -1;

        while (hasInput()) {
            lastState = state;
            state = nextState(nextChar(), state);

            if (state < 0)
                break;

            else {
                if (tokenForState(state) >= 0) {
                    endState = state;
                    end = position;
                }
            }
        }

        if (endState < 0 || (endState != state && tokenForState(lastState) == -2))
            throw new LexicalError(SCANNER_ERROR[lastState], getLine(start), getSymbolString(start));
            // input.substring(start,position);

        position = end;

        int token = tokenForState(endState);

        if (token == 0)
            return nextToken();
        else {
            String lexeme = input.substring(start, end);
            token = lookupToken(token, lexeme);

            if ((token == 2) && !(Arrays.asList(SPECIAL_CASES_KEYS).contains(lexeme)))
                throw new LexicalError(SCANNER_ERROR[1], getLine(start), getSymbolString(start));

            return new Token(getClass(token), lexeme, getLine(start));
        }
    }

    private String getClass (int token){
        if (token>6 && token<20){
            return "pr";
        } else if (token>19 && token<36) {
            return "se";
        } else {
            return id_string[token];
        }
    }

    private String getSymbolString(int start){
        String symbolString = input.substring(start, start+1);

        while (start<input.length()-1 && !Character.isWhitespace(input.charAt(start + 1))) {
            start++;
            symbolString += input.substring(start, start+1);
        }

        return symbolString;
    }

    private int nextState(char c, int state) {
        int start = SCANNER_TABLE_INDEXES[state];
        int end = SCANNER_TABLE_INDEXES[state + 1] - 1;

        while (start <= end) {
            int half = (start + end) / 2;

            if (SCANNER_TABLE[half][0] == c)
                return SCANNER_TABLE[half][1];
            else if (SCANNER_TABLE[half][0] < c)
                start = half + 1;
            else // (SCANNER_TABLE[half][0] > c)
                end = half - 1;
        }

        return -1;
    }

    private int tokenForState(int state) {
        if (state < 0 || state >= TOKEN_STATE.length)
            return -1;

        return TOKEN_STATE[state];
    }

    public int lookupToken(int base, String key) {
        int start = SPECIAL_CASES_INDEXES[base];
        int end = SPECIAL_CASES_INDEXES[base + 1] - 1;

        while (start <= end) {
            int half = (start + end) / 2;
            int comp = SPECIAL_CASES_KEYS[half].compareTo(key);

            if (comp == 0)
                return SPECIAL_CASES_VALUES[half];
            else if (comp < 0)
                start = half + 1;
            else // (comp > 0)
                end = half - 1;
        }

        return base;
    }

    private boolean hasInput() {
        return position < input.length();
    }

    private char nextChar() {
        if (hasInput())
            return input.charAt(position++);
        else
            return (char) -1;
    }

    private int getLine(int tokenPosition) {
        int charCount = 0;

        int line = 0;

        for (int i = 0; i < lines.length; i++) {
            charCount += lines[i].length() + 1;
            if (charCount > tokenPosition) {
                line = i + 1;
                break;
            }
        }

        return line;

    }
}
